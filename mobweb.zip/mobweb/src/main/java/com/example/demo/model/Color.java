package com.example.demo.model;

public enum Color {
    RED,BLUE,BLACK,WHITE,PINK
}
