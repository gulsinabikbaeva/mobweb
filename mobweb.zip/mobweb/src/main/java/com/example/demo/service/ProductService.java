package com.example.demo.service;

import com.example.demo.model.*;
import com.example.demo.repository.CategoriaRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> findAll() {
        return productRepository.findAll();
    }


    @Autowired
    private UserRepository ur;

    @Autowired
    private CategoriaRepository cr;

    @Autowired
    private RoleRepository rr;


    @PostConstruct
    public void init() {

        if(productRepository.findAll().size() == 0) {
            Product product = new Product();
            // manca categoria e user

            product.setName("prodotto1");
           // product.setCategoria(CategoriaEnum.JEWELLERY);
            product.setPrice(20);
            product.setDescription("descrizione prodotto 1");
            product.setColor(Color.BLACK);
            product.setScontoProdotto(2);
            product.setComposition(ProductCompositionEnum.CLAY);
            //product.setFoto1("https://media6.ppl-media.com/tr:h-750,w-750,c-at_max/static/img/product/134451/crunchy-fashion-monocromatic-dapper-earings_1_display_1514549697_fb1318b8.jpg");
            //product.setFoto2("https://www.charriol.com/3778-thickbox_default/earings-twilight.jpg");
            //product.setFoto3("https://image.made-in-china.com/202f0j00CoQWyNbnGSck/Mlgm-Statement-Earring-for-Women-Rainbow-Jewelry-Trendy-Bohemian-Colorful-Bead-Earings-Japanese-Miyuki-Beads-Ear-Ring-Hoop-Fine-Imitation-Beaded-Earrings.jpg");
            //postProduct(product);

        }
    }

    public List<Product> getAll(){
        return productRepository.findAll();
    }

    public Product get(Long id){
        return productRepository.findById(id).get();
    }

    public Product postProduct(Product p){
        return productRepository.save(p);
    }

    public Product putProduct(Product p) {
        return productRepository.save(p);
    }

    public boolean exists(Long id) {
        return productRepository.existsById(id);
    }

    public boolean deleteProduct(Long id){
        productRepository.deleteById(id);
        if(productRepository.existsById(id)){
            return false;
        }
        return true;
    }

    public List<Categoria> getCategories(){
        return  cr.findAll();
    }


}
