package com.example.demo.service;

import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.List;

import static com.example.demo.model.CategoriaEnum.*;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    public List<CustomerOrder> findAll() {
        return orderRepository.findAll();
    }

    public void save(CustomerOrder c) {
        orderRepository.save(c);
    }


    @Autowired
    private UserRepository ur;

    @Autowired
    private RoleRepository rr;


    @PostConstruct
    public void init() {

        if(orderRepository.findAll().size() == 0) {
            CustomerOrder order = new CustomerOrder();
            //mancano double subTotal e total;
            order.setDate(new Date());
            order.setScontoOrdinePercentuale(10);
            order.setScontoOrdineImporto(15);
            order.setSpedizione(20);
            post(order);

        }
    }

    public List<CustomerOrder> getAll(){
        return orderRepository.findAll();
    }

    public CustomerOrder get(Long id){
        return orderRepository.findById(id).get();
    }

    public CustomerOrder post(CustomerOrder p){
        return orderRepository.save(p);
    }

    public CustomerOrder put(CustomerOrder p) {
        return orderRepository.save(p);
    }

    public boolean exists(Long id) {
        return orderRepository.existsById(id);
    }

    public boolean delete(Long id){
        orderRepository.deleteById(id);
        if(orderRepository.existsById(id)){
            return false;
        }
        return true;
    }

}
