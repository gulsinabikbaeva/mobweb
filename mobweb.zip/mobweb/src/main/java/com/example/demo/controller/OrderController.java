package com.example.demo.controller;

import com.example.demo.dto.OrderDTO;
import com.example.demo.dto.Success;
import com.example.demo.model.CustomerOrder;
import com.example.demo.service.OrderService;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/ordersPaid")
public class OrderController {
    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }
    @GetMapping("")
    public List<OrderDTO> list(){
        return service.getAll().stream().map(order -> OrderDTO.order2DTO(order)).collect(Collectors.toList());
    }
    @GetMapping(value="/{id}")
    public ResponseEntity<OrderDTO> getOrder(@PathVariable Long id){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        CustomerOrder order = service.get(id);
        return order != null ? new ResponseEntity<>(OrderDTO.order2DTO(order), HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping(value="")
    public ResponseEntity<OrderDTO> postOrder(@RequestBody CustomerOrder order){
        order = service.post(order);
        return new ResponseEntity<>(OrderDTO.order2DTO(order), HttpStatus.CREATED);
    }

    @PutMapping(value="/{id}")
    public ResponseEntity<OrderDTO> putOrder(@PathVariable Long id, @RequestBody CustomerOrder order){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        order.setId(id);
        service.put(order);
        return new ResponseEntity<>(OrderDTO.order2DTO(order), HttpStatus.OK);
    }

    @DeleteMapping(value="/{id}")
    public ResponseEntity<Success> deleteOrder(@PathVariable Long id){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        boolean remove = service.delete(id);
        if(remove) return new ResponseEntity<>(new Success(true), HttpStatus.OK);
        else return new ResponseEntity<>(new Success(false), HttpStatus.OK);
    }
}
