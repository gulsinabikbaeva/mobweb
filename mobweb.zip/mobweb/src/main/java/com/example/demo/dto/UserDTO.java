package com.example.demo.dto;

import com.example.demo.model.Address;
import com.example.demo.model.CustomerOrder;
import com.example.demo.model.Role;
import com.example.demo.model.User;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import java.util.Date;

@Setter
@Getter
@Builder
public class UserDTO {

    private Long id;
    private String username;
    private String password;
    private double buonoGiftCard;
    private String name;
    private String surname;
    private String phone;
    private String email;
    private Address address;
    private Role role;

    public static UserDTO user2DTO(User user){
        return UserDTO.builder().id(user.getId())
                .username(user.getUsername())
                .password(user.getPassword())
                .buonoGiftCard(user.getBuonoGiftCard())
                .name(user.getName())
                .surname(user.getSurname())
                .phone(user.getPhone())
                .email(user.getEmail())
                .address(user.getAddress())
                .role(user.getRole())
                .build();
    }

}
