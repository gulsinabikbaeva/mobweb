package com.example.demo.model;

public enum CategoriaWomenswearEnum {
    TOPS,BOTTOMS,UNDERWEAR,OUTWEAR,ACCESSORIES
}
