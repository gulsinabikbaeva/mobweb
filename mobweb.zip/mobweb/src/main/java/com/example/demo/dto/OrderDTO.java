package com.example.demo.dto;

import com.example.demo.model.CustomerOrder;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@Builder
public class OrderDTO {

    private Long id;
    private Date date;
    private double subTotal;
    private int scontoOrdinePercentuale; // esempio 10%
    private int scontoOrdineImporto; // esempio 100 USD
    private double spedizione;
    private double total;

    public static OrderDTO order2DTO(CustomerOrder order){
        return OrderDTO.builder().id(order.getId())
                .date(order.getDate())
                .subTotal(order.getSubTotal())
                .scontoOrdinePercentuale(order.getScontoOrdinePercentuale())
                .scontoOrdineImporto(order.getScontoOrdineImporto())
                .spedizione(order.getSpedizione())
                .total(order.getTotal())
                .build();
    }

}
