package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CustomerOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Date date;
    private double subTotal;
    private int scontoOrdinePercentuale; // esempio 10%
    private int scontoOrdineImporto; // esempio 100 USD
    private double spedizione;
    private double total;


    @ManyToOne
    private User user;

    @OneToMany
    private List<Product> products; // dovrei salvare anche la quantità -> map?
}
