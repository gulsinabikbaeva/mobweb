package com.example.demo.model;

public enum ProductCompositionEnum {
    CLAY,POLYESTER,COTTON,MIXTEXTILE
}
