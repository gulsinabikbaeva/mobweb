package com.example.demo.model;

public enum CategoriaJewelleryEnum {
    NECKLACES,BODYJEWELLERY,EARINGS
}
