package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Categoria {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private CategoriaEnum nomeCategoria;

    public Categoria (CategoriaEnum c){
        this.nomeCategoria=c;
    }

    @ManyToOne(cascade = {CascadeType.PERSIST})
    private Product product;
}
