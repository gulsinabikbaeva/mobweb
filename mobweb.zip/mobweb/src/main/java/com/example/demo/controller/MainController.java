package com.example.demo.controller;

import com.example.demo.model.CustomerOrder;
import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.service.OrderService;
import com.example.demo.service.ProductService;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Date;

@Controller
public class MainController {

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index(Model model) {
        return "shop";
    }

   /* @GetMapping("/orders")
    public String orders(Model model) {
        model.addAttribute("orders", orderService.findAll());
        return "orders";
    }

    @GetMapping("/products")
    public String products(Model model) {
        model.addAttribute("products", productService.findAll());
        return "products";
    }
    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userService.findAll());
        return "users";
    }
    */

    //-----------user

    @GetMapping("/user/{id}")
    public String detailUser(@PathVariable Long id, Model model){
        model.addAttribute("user", userService.get(id));
        return "detailUser";
    }

    @GetMapping("/user/newUser")
    public String newPostUser(Model model){
        model.addAttribute("user", new User());
        return "editUser";
    }

    @PostMapping("/user/newUser")
    public String postUser(User user){
        userService.post(user);
        return "redirectUser:/";
    }

    @GetMapping("/user/{id}/editUser")
    public String editUser(@PathVariable Long id, Model model){
        User user = userService.get(id);
        model.addAttribute("user", user);
        return "editUser";
    }

    @PostMapping("/user/{id}/editUser")
    public String putUser(@PathVariable Long id, User newUser){
        User user = userService.get(id);
        newUser.setId(id);
        userService.put(newUser);
        return "redirectUser:/user/{id}";
    }

    @GetMapping(value = "/user/{id}/deleteUser")
    public String detailUser(@PathVariable Long id){
        userService.delete(id);
        return "redirectUser:/";
    }
    //----------product

    @GetMapping("/product/{id}")
    public String detailProduct(@PathVariable Long id, Model model){
        model.addAttribute("product", productService.get(id));
        return "detailProduct";
    }

    @GetMapping("/product/newProduct")
    public String newPostProduct(Model model){
        model.addAttribute("product", new Product());
        model.addAttribute("categories", productService.getCategories());
        return "editProduct";
    }

    @PostMapping("/product/newProduct")
    public String postProduct(Product product){
        productService.postProduct(product);
        return "redirectProduct:/";
    }

    @GetMapping("/product/{id}/editProduct")
    public String editProduct(@PathVariable Long id, Model model){
        Product product = productService.get(id);
        model.addAttribute("productProduct", product);
        model.addAttribute("categories", productService.getCategories());
        return "editProduct";
    }

    @PostMapping("/product/{id}/editProduct")
    public String putProduct(@PathVariable Long id, Product newProduct){
        Product product = productService.get(id);
        newProduct.setId(id);
        productService.putProduct(newProduct);
        return "redirectProduct:/product/{id}";
    }

    @GetMapping(value = "/product/{id}/deleteProduct")
    public String detailProduct(@PathVariable Long id){
        productService.deleteProduct(id);
        return "redirectProduct:/";
    }
    //----------order

    @GetMapping("/order/{id}")
    public String detailOrder(@PathVariable Long id, Model model){
        model.addAttribute("order", orderService.get(id));
        return "detailOrder";
    }

    @GetMapping("/order/newOrder")
    public String newPostOrder(Model model){
        model.addAttribute("order", new CustomerOrder());
        return "editOrder";
    }

    @PostMapping("/order/newOrder")
    public String postOrder(CustomerOrder order){
        order.setDate(new Date());
        orderService.post(order);
        return "redirectOrder:/";
    }

    @GetMapping("/order/{id}/editOrder")
    public String editOrder(@PathVariable Long id, Model model){
        CustomerOrder order = orderService.get(id);
        model.addAttribute("order", order);
        return "editOrder";
    }

    @PostMapping("/order/{id}/editOrder")
    public String putOrder(@PathVariable Long id, CustomerOrder newOrder){
        CustomerOrder order = orderService.get(id);
        newOrder.setId(id);
        newOrder.setDate(order.getDate());
        orderService.put(newOrder);
        return "redirectOrder:/order/{id}";
    }

    @GetMapping(value = "/order/{id}/deleteOrder")
    public String detailOrder(@PathVariable Long id){
        orderService.delete(id);
        return "redirectOrder:/";
    }
}
