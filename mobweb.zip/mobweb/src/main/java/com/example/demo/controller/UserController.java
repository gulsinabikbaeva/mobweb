package com.example.demo.controller;

import com.example.demo.dto.ProductDTO;
import com.example.demo.dto.Success;
import com.example.demo.dto.UserDTO;
import com.example.demo.model.User;
import com.example.demo.service.ProductService;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService service;

    public UserController(UserService service) {
        this.service = service;
    }

    @GetMapping("")
    public List<UserDTO> list(){
        return service.getAll().stream().map(user -> UserDTO.user2DTO(user)).collect(Collectors.toList());
    }

    @GetMapping(value="/{id}")
    public ResponseEntity<UserDTO> getUser(@PathVariable Long id){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        User user = service.get(id);
        return user != null ? new ResponseEntity<>(UserDTO.user2DTO(user), HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping(value="")
    public ResponseEntity<UserDTO> postUser(@RequestBody User user){
        user = service.post(user);
        return new ResponseEntity<>(UserDTO.user2DTO(user), HttpStatus.CREATED);
    }

    @PutMapping(value="/{id}")
    public ResponseEntity<UserDTO> putUser(@PathVariable Long id, @RequestBody User user){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        user.setId(id);
        service.put(user);
        return new ResponseEntity<>(UserDTO.user2DTO(user), HttpStatus.OK);
    }

    @DeleteMapping(value="/{id}")
    public ResponseEntity<Success> deleteUser(@PathVariable Long id){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        boolean remove = service.delete(id);
        if(remove) return new ResponseEntity<>(new Success(true), HttpStatus.OK);
        else return new ResponseEntity<>(new Success(false), HttpStatus.OK);
    }

}
