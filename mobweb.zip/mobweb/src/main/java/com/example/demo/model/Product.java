package com.example.demo.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String name;

    @ManyToOne(cascade = {CascadeType.PERSIST})
    private Categoria categoria;

    private double price;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    private Color color;

    private int scontoProdotto;

    @ManyToOne(cascade = {CascadeType.PERSIST})
    private User user;

    @Enumerated(EnumType.STRING)
    private ProductCompositionEnum composition;

    @Column(columnDefinition = "TEXT")
    private String foto1;

    @Column(columnDefinition = "TEXT")
    private String foto2;

    @Column(columnDefinition = "TEXT")
    private String foto3;


}
