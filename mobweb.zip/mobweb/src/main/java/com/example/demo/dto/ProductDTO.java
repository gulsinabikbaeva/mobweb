package com.example.demo.dto;

import com.example.demo.model.*;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Setter
@Getter
@Builder
public class ProductDTO {
    private Long id;
    private String name;
    private Categoria categoria;
    private double price;
    private String description;
    private Color color;
    private int scontoProdotto;
    private User user;
    private ProductCompositionEnum composition;
    private String foto1;
    private String foto2;
    private String foto3;

    public static ProductDTO product2DTO(Product product){
        return ProductDTO.builder().id(product.getId())
                .name(product.getName())
                .categoria(product.getCategoria())
                .price(product.getPrice())
                .description(product.getDescription())
                .color(product.getColor())
                .scontoProdotto(product.getScontoProdotto())
                .composition(product.getComposition())
                .foto1(product.getFoto1())
                .foto2(product.getFoto2())
                .foto3(product.getFoto3())
                .build();
    }
}
