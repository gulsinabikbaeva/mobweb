package com.example.demo.service;

import com.example.demo.model.*;
import com.example.demo.repository.CategoriaRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public List<User> findAll() {
        return userRepository.findAll();
    }
    @Autowired
    private RoleRepository rr;


    @PostConstruct
    public void init() {
        if(userRepository.findAll().size() == 0) {
            Role rAdmin = new Role("ADMIN");
            Role rCustomer = new Role("CUSTOMER");
            Role rSeller = new Role("SELLER");
            rr.save(rAdmin);
            rr.save(rCustomer);
            rr.save(rSeller);

            User admin = new User();
            admin.setId(1L);
            admin.setName("admin");
            admin.setRole(rAdmin);
            User customer1 = new User();
            customer1.setId(1L);
            customer1.setName("customer");
            customer1.setRole(rCustomer);
            User seller1 = new User();
            seller1.setId(1L);
            seller1.setName("seller");
            seller1.setRole(rSeller);

            userRepository.save(admin);
            userRepository.save(customer1);
            userRepository.save(seller1);
            post(admin);
            post(customer1);
            post(seller1);

        }
    }

    public List<User> getAll(){
        return userRepository.findAll();
    }

    public User get(Long id){
        return userRepository.findById(id).get();
    }

    public User post(User p){
        return userRepository.save(p);
    }

    public User put(User p) {
        return userRepository.save(p);
    }

    public boolean exists(Long id) {
        return userRepository.existsById(id);
    }

    public boolean delete(Long id){
        userRepository.deleteById(id);
        if(userRepository.existsById(id)){
            return false;
        }
        return true;
    }


}
