package com.example.demo.controller;

import com.example.demo.dto.ProductDTO;
import com.example.demo.dto.Success;
import com.example.demo.model.Product;
import com.example.demo.service.OrderService;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping("")
    public List<ProductDTO> list(){
        return service.getAll().stream().map(product -> ProductDTO.product2DTO(product)).collect(Collectors.toList());
    }

    @GetMapping(value="/{id}")
    public ResponseEntity<ProductDTO> getProduct(@PathVariable Long id){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        Product product = service.get(id);
        return product != null ? new ResponseEntity<>(ProductDTO.product2DTO(product), HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping(value="")
    public ResponseEntity<ProductDTO> postProduct(@RequestBody Product product){
        product = service.postProduct(product);
        return new ResponseEntity<>(ProductDTO.product2DTO(product), HttpStatus.CREATED);
    }

    @PutMapping(value="/{id}")
    public ResponseEntity<ProductDTO> putProduct(@PathVariable Long id, @RequestBody Product product){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        product.setId(id);
        service.putProduct(product);
        return new ResponseEntity<>(ProductDTO.product2DTO(product), HttpStatus.OK);
    }

    @DeleteMapping(value="/{id}")
    public ResponseEntity<Success> deleteProduct(@PathVariable Long id){
        if (!service.exists(id)) return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        boolean remove = service.deleteProduct(id);
        if(remove) return new ResponseEntity<>(new Success(true), HttpStatus.OK);
        else return new ResponseEntity<>(new Success(false), HttpStatus.OK);
    }
}
